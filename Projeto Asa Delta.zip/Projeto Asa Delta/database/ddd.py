# -*- coding: utf-8 -*-
Ired='\033[1;31m'; Dgreen='\033[1;32m'; Nyellow='\033[1;33m'
Hcyan='\033[1;36m'; Iblue='\033[1;34m'; VRCRM='\033[0;0m'
import os, requests
from database.frases import get as frase

def clear(): os.system('cls' if os.name == 'nt' else 'clear')

def consultar():
    clear()
    print(f'\n{Iblue}{"=" * 50}')
    print(f'              CONSULTA DDD')
    print(f'{Iblue}{"=" * 50}{VRCRM}')
    restart = 'S'
    while restart == 'S':
        while True:
            ddd_input = input(f'\n{Hcyan}DDD (2 digitos, ex: 11): {VRCRM}').strip()
            if not ddd_input.isdigit() or len(ddd_input) != 2:
                print(f'{Ired}!!! DDD Invalido !!!')
            else:
                break
        try:
            r = requests.get(f'https://brasilapi.com.br/api/ddd/v1/{ddd_input}', timeout=8)
            rj = r.json()
        except Exception as e:
            print(f'{Ired}Erro de conexao: {e}')
            restart = input(f'\n{Hcyan}Tentar novamente? S/N: {VRCRM}').strip().upper()[:1]
            clear(); continue

        if r.status_code != 200 or 'message' in rj:
            restart = input(f'{Ired}==> DDD NAO ENCONTRADO <==\n\n{Hcyan}Outra consulta? S/N: {VRCRM}').strip().upper()[:1]
            clear()
        else:
            print(f'\n{Nyellow}{"=" * 50}')
            print(f'{Dgreen}  ==> DDD ENCONTRADO <==')
            print(f'{Ired}  {frase()}')
            print(f'{Nyellow}{"=" * 50}{VRCRM}')
            print(f'  DDD           >>> {ddd_input}')
            print(f'  Estado        >>> {rj.get("state", "-")}')
            cidades = rj.get('cities', [])
            print(f'  Cidades ({len(cidades)}):')
            for c in cidades[:20]:
                print(f'    - {c}')
            if len(cidades) > 20:
                print(f'    ... e mais {len(cidades)-20} cidades')
            print(f'{Nyellow}{"=" * 50}{VRCRM}')
            restart = input(f'\n{Hcyan}Outra consulta? S/N: {VRCRM}').strip().upper()[:1]
            clear()
