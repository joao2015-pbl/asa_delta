# -*- coding: utf-8 -*-
Ired='\033[1;31m'; Dgreen='\033[1;32m'; Nyellow='\033[1;33m'
Hcyan='\033[1;36m'; Iblue='\033[1;34m'; Gpurple='\033[1;35m'; VRCRM='\033[0;0m'
import os, requests, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from database.frases import get as frase

def clear(): os.system('cls' if os.name == 'nt' else 'clear')

SITES = {
    'GitHub':       ('https://github.com/{}',               200),
    'Instagram':    ('https://www.instagram.com/{}/',        200),
    'Twitter/X':    ('https://twitter.com/{}',               200),
    'TikTok':       ('https://www.tiktok.com/@{}',           200),
    'YouTube':      ('https://www.youtube.com/@{}',          200),
    'Reddit':       ('https://www.reddit.com/user/{}/',      200),
    'Twitch':       ('https://www.twitch.tv/{}',             200),
    'Pinterest':    ('https://www.pinterest.com/{}/',        200),
    'Telegram':     ('https://t.me/{}',                      200),
    'Steam':        ('https://steamcommunity.com/id/{}/',    200),
    'Roblox':       ('https://www.roblox.com/user.aspx?username={}', 200),
    'Tumblr':       ('https://{}.tumblr.com/',               200),
    'Medium':       ('https://medium.com/@{}',               200),
    'DeviantArt':   ('https://www.deviantart.com/{}',        200),
    'Spotify':      ('https://open.spotify.com/user/{}',     200),
    'SoundCloud':   ('https://soundcloud.com/{}',            200),
    'Kwai':         ('https://www.kwai.com/u/{}',            200),
    'Linktree':     ('https://linktr.ee/{}',                 200),
    'Cash App':     ('https://cash.app/${}',                 200),
    'Last.fm':      ('https://www.last.fm/user/{}',          200),
}

HEADERS = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}

def checar(nome, url_tpl, codigo_ok, username):
    url = url_tpl.format(username)
    try:
        r = requests.get(url, headers=HEADERS, timeout=6, allow_redirects=True)
        encontrado = r.status_code == codigo_ok
        return (nome, url, encontrado)
    except:
        return (nome, url, None)

def consultar():
    clear()
    print(f'\n{Iblue}{"=" * 50}')
    print(f'            USERNAME OSINT')
    print(f'{Iblue}{"=" * 50}{VRCRM}')
    restart = 'S'
    while restart == 'S':
        username = input(f'\n{Hcyan}Username para buscar: {VRCRM}').strip()
        if not username:
            continue
        print(f'\n{Nyellow}  Varrendo {len(SITES)} plataformas...{VRCRM}')
        encontrados = []
        nao_encontrados = []
        erros = []

        with ThreadPoolExecutor(max_workers=10) as ex:
            futures = {ex.submit(checar, n, u, c, username): n for n,(u,c) in SITES.items()}
            for fut in as_completed(futures):
                nome, url, ok = fut.result()
                if ok is True:
                    encontrados.append((nome, url))
                    print(f'  {Dgreen}[+]{VRCRM} {nome}')
                elif ok is False:
                    nao_encontrados.append(nome)
                else:
                    erros.append(nome)

        print(f'\n{Nyellow}{"=" * 50}')
        print(f'{Dgreen}  ==> USERNAME: {username} <==')
        print(f'{Ired}  {frase()}')
        print(f'{Nyellow}{"=" * 50}{VRCRM}')
        print(f'\n  {Dgreen}ENCONTRADO em {len(encontrados)} plataformas:{VRCRM}')
        for nome, url in sorted(encontrados):
            print(f'  {Dgreen}[+]{VRCRM} {nome:<15} {url}')
        if nao_encontrados:
            print(f'\n  {Ired}NAO encontrado em: {", ".join(nao_encontrados)}{VRCRM}')
        if erros:
            print(f'  {Nyellow}Timeout/erro em: {", ".join(erros)}{VRCRM}')
        print(f'\n{Nyellow}{"=" * 50}{VRCRM}')
        restart = input(f'\n{Hcyan}Outro username? S/N: {VRCRM}').strip().upper()[:1]
        clear()
