# -*- coding: utf-8 -*-
Ired='\033[1;31m'; Dgreen='\033[1;32m'; Nyellow='\033[1;33m'
Hcyan='\033[1;36m'; Iblue='\033[1;34m'; VRCRM='\033[0;0m'
import os, requests
from database.frases import get as frase

def clear(): os.system('cls' if os.name == 'nt' else 'clear')

def consultar():
    clear()
    print(f'\n{Iblue}{"=" * 50}')
    print(f'           GEOLOCALIZADOR DE IP')
    print(f'{Iblue}{"=" * 50}{VRCRM}')
    restart = 'S'
    while restart == 'S':
        ip_input = input(f'\n{Hcyan}Digite o IP: {VRCRM}').strip()
        try:
            r = requests.get(f'http://ip-api.com/json/{ip_input}?fields=status,message,country,countryCode,regionName,city,zip,lat,lon,timezone,isp,org,as,query', timeout=8)
            rj = r.json()
        except Exception as e:
            print(f'{Ired}Erro de conexao: {e}')
            restart = input(f'\n{Hcyan}Tentar novamente? S/N: {VRCRM}').strip().upper()[:1]
            clear(); continue

        if rj.get('status') == 'fail':
            restart = input(f'{Ired}==> IP NAO ENCONTRADO <==\n\n{Hcyan}Outra consulta? S/N: {VRCRM}').strip().upper()[:1]
            clear()
        else:
            print(f'\n{Nyellow}{"=" * 50}')
            print(f'{Dgreen}  ==> IP ENCONTRADO <==')
            print(f'{Ired}  {frase()}')
            print(f'{Nyellow}{"=" * 50}{VRCRM}')
            print(f'  IP            >>> {rj.get("query", "-")}')
            print(f'  Pais          >>> {rj.get("country", "-")} ({rj.get("countryCode", "-")})')
            print(f'  Regiao        >>> {rj.get("regionName", "-")}')
            print(f'  Cidade        >>> {rj.get("city", "-")}')
            print(f'  CEP           >>> {rj.get("zip", "-")}')
            print(f'  Latitude      >>> {rj.get("lat", "-")}')
            print(f'  Longitude     >>> {rj.get("lon", "-")}')
            print(f'  Fuso Horario  >>> {rj.get("timezone", "-")}')
            print(f'  Provedor      >>> {rj.get("isp", "-")}')
            print(f'  Organizacao   >>> {rj.get("org", "-")}')
            print(f'{Nyellow}{"=" * 50}{VRCRM}')
            restart = input(f'\n{Hcyan}Outra consulta? S/N: {VRCRM}').strip().upper()[:1]
            clear()
