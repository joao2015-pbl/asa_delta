# -*- coding: utf-8 -*-
Ired='\033[1;31m'; Dgreen='\033[1;32m'; Nyellow='\033[1;33m'
Hcyan='\033[1;36m'; Iblue='\033[1;34m'; VRCRM='\033[0;0m'
import os, requests
from database.frases import get as frase

def clear(): os.system('cls' if os.name == 'nt' else 'clear')

def consultar():
    clear()
    print(f'\n{Iblue}{"=" * 50}')
    print(f'             CONSULTA NUMERO')
    print(f'{Iblue}{"=" * 50}{VRCRM}')
    restart = 'S'
    while restart == 'S':
        while True:
            num = input(f'\n{Hcyan}Numero (ex: 11987654321): {VRCRM}').strip()
            num_clean = ''.join(c for c in num if c.isdigit() or c == '+')
            if not num_clean.startswith('+'):
                num_clean = '+55' + num_clean.lstrip('0')
            if len(num_clean) < 12:
                print(f'{Ired}!!! Numero muito curto. Inclua o DDD !!!')
            else:
                break
        try:
            import phonenumbers
            from phonenumbers import carrier, geocoder, timezone, number_type, PhoneNumberType
            parsed = phonenumbers.parse(num_clean, None)
            valido = phonenumbers.is_valid_number(parsed)
            tipo_raw = number_type(parsed)
            tipo_map = {
                PhoneNumberType.MOBILE: 'Celular',
                PhoneNumberType.FIXED_LINE: 'Fixo',
                PhoneNumberType.FIXED_LINE_OR_MOBILE: 'Fixo ou Celular',
                PhoneNumberType.TOLL_FREE: 'Gratuito',
                PhoneNumberType.VOIP: 'VoIP',
                PhoneNumberType.UNKNOWN: 'Desconhecido',
            }
            tipo_str = tipo_map.get(tipo_raw, 'Desconhecido')
            operadora = carrier.name_for_number(parsed, 'pt') or carrier.name_for_number(parsed, 'en') or 'N/A'
            regiao    = geocoder.description_for_number(parsed, 'pt') or 'N/A'
            fusos     = list(timezone.time_zones_for_number(parsed))
            ddd       = str(parsed.national_number)[:2]

            print(f'\n{Nyellow}{"=" * 50}')
            print(f'{Dgreen}  ==> NUMERO ENCONTRADO <==')
            print(f'{Ired}  {frase()}')
            print(f'{Nyellow}{"=" * 50}{VRCRM}')
            print(f'  Numero        >>> {phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.INTERNATIONAL)}')
            print(f'  Valido        >>> {"Sim" if valido else "Nao"}')
            print(f'  Tipo          >>> {tipo_str}')
            print(f'  Operadora     >>> {operadora}')
            print(f'  Regiao        >>> {regiao}')
            print(f'  DDD           >>> {ddd}')
            print(f'  Fuso Horario  >>> {", ".join(fusos) if fusos else "N/A"}')
            try:
                r = requests.get(f'https://brasilapi.com.br/api/ddd/v1/{ddd}', timeout=5)
                if r.status_code == 200:
                    rj = r.json()
                    print(f'  Estado        >>> {rj.get("state", "N/A")}')
            except: pass
            print(f'{Nyellow}{"=" * 50}{VRCRM}')
        except ImportError:
            os.system('python -m pip install phonenumbers')
            print(f'{Dgreen}Instalado! Tente novamente.{VRCRM}')
        except Exception as e:
            print(f'{Ired}Erro: {e}{VRCRM}')
        restart = input(f'\n{Hcyan}Outra consulta? S/N: {VRCRM}').strip().upper()[:1]
        clear()
