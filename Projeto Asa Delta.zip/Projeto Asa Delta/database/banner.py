# -*- coding: utf-8 -*-
Mblack = '\033[1;30m'
Ired   = '\033[1;31m'
Dgreen = '\033[1;32m'
Nyellow= '\033[1;33m'
Iblue  = '\033[1;34m'
Gpurple= '\033[1;35m'
Hcyan  = '\033[1;36m'
Twhite = '\033[1;37m'
VRCRM  = '\033[0;0m'
import os

def clear(): os.system('cls' if os.name == 'nt' else 'clear')



def menu():
    clear()
    linha = Ired + ('=' * 66) + VRCRM                              
    print(Hcyan    + '      ▄▀█ █▀▀ ▄▀█   █▀▄ █▀▀ █   ▀█▀ ▄▀█        ' + VRCRM)
    print(Hcyan    + '      █▀█ ▄▄█ █▀█   █▄▀ ██▄ █▄▄  █  █▀█        ' + VRCRM)
    print(Hcyan    + '                                             ' + VRCRM)
    print(Nyellow  + '          [ Painel de Consultas v1.0  -  Free & Open ]   ' + VRCRM)
    print(linha)
    print(Ired + '  CONSULTAS' + ' '*10 + 'FERRAMENTAS' + ' '*6 + 'OPCOES' + VRCRM)
    print(linha)
    print(Nyellow + '  [01]' + Dgreen + ' Username OSINT   ' + Ired + '|  ' + Nyellow + '[12]' + Iblue + ' Scan de Portas   ' + Ired + '|  ' + Nyellow + '[17]' + Gpurple + ' Ajuda' + VRCRM)
    print(Nyellow + '  [02]' + Dgreen + ' Numero Temp      ' + Ired + '|  ' + Nyellow + '[13]' + Iblue + ' Traceroute       ' + Ired + '|  ' + Nyellow + '[18]' + Twhite + ' Atualizar' + VRCRM)
    print(Nyellow + '  [03]' + Dgreen + ' IP Geolocalizacao' + Ired + '|  ' + Nyellow + '[14]' + Iblue + ' Gerar Relatorio  ' + Ired + '|  ' + Nyellow + '[19]' + Twhite + ' Sair' + VRCRM)
    print(Nyellow + '  [04]' + Dgreen + ' Email OSINT      ' + Ired + '|  ' + Nyellow + '[15]' + Iblue + ' Banco Info       ' + Ired + '|' + VRCRM)
    print(Nyellow + '  [05]' + Dgreen + ' Numero           ' + Ired + '|  ' + Nyellow + '[16]' + Iblue + ' Admin Checker    ' + Ired + '|' + VRCRM)
    print(Nyellow + '  [06]' + Dgreen + ' WHOIS Dominio    ' + Ired + '|' + VRCRM)
    print(Nyellow + '  [07]' + Dgreen + ' CEP              ' + Ired + '|' + VRCRM)
    print(Nyellow + '  [08]' + Dgreen + ' CNPJ             ' + Ired + '|' + VRCRM)
    print(Nyellow + '  [09]' + Dgreen + ' Placa            ' + Ired + '|' + VRCRM)
    print(Nyellow + '  [10]' + Dgreen + ' BIN Cartao       ' + Ired + '|' + VRCRM)
    print(Nyellow + '  [11]' + Dgreen + ' DDD              ' + Ired + '|' + VRCRM)
    print(linha)
    print('')
