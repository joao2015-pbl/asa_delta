# -*- coding: utf-8 -*-
import random

FRASES = [
    "nao pergunta de onde veio, so agradece por ter chegado.",
    "voce nem sabe a metade do que a gente sabe sobre voce.",
    "o sistema e aberto pra quem sabe onde olhar.",
    "informacao e poder. e a gente tem bastante dos dois.",
    "mais facil do que voce pensava, ne?",
    "privacidade e ilusao pra quem nao sabe se proteger.",
    "nao e invasao, e curiosidade com habilidade.",
    "a internet nao esquece. nos tambem nao.",
    "tudo que e publico, nos alcancamos.",
    "conhecimento nao se pede, se conquista.",
]

def get(): return random.choice(FRASES)
