# -*- coding: utf-8 -*-
Ired='\033[1;31m'; Dgreen='\033[1;32m'; Nyellow='\033[1;33m'
Hcyan='\033[1;36m'; Iblue='\033[1;34m'; VRCRM='\033[0;0m'
import os, requests
from database.frases import get as frase

def clear(): os.system('cls' if os.name == 'nt' else 'clear')

def consultar():
    clear()
    print(f'\n{Iblue}{"=" * 50}')
    print(f'              CONSULTA CEP')
    print(f'{Iblue}{"=" * 50}{VRCRM}')
    restart = 'S'
    while restart == 'S':
        while True:
            cep_input = input(f'\n{Hcyan}CEP (somente numeros): {VRCRM}').strip().replace('-','')
            if len(cep_input) != 8 or not cep_input.isdigit():
                print(f'{Ired}!!! CEP Invalido (8 digitos) !!!')
            else:
                break
        try:
            r = requests.get(f'https://brasilapi.com.br/api/cep/v2/{cep_input}', timeout=8)
            rj = r.json()
        except Exception as e:
            print(f'{Ired}Erro de conexao: {e}')
            restart = input(f'\n{Hcyan}Tentar novamente? S/N: {VRCRM}').strip().upper()[:1]
            clear(); continue

        if r.status_code != 200 or 'message' in rj:
            restart = input(f'{Ired}==> CEP NAO ENCONTRADO <==\n\n{Hcyan}Outra consulta? S/N: {VRCRM}').strip().upper()[:1]
            clear()
        else:
            print(f'\n{Nyellow}{"=" * 50}')
            print(f'{Dgreen}  ==> CEP ENCONTRADO <==')
            print(f'{Ired}  {frase()}')
            print(f'{Nyellow}{"=" * 50}{VRCRM}')
            print(f'  CEP           >>> {rj.get("cep", "-")}')
            print(f'  Logradouro    >>> {rj.get("street", "-")}')
            print(f'  Bairro        >>> {rj.get("neighborhood", "-")}')
            print(f'  Cidade        >>> {rj.get("city", "-")}')
            print(f'  Estado        >>> {rj.get("state", "-")}')
            loc = rj.get('location', {}).get('coordinates', {})
            if loc:
                print(f'  Latitude      >>> {loc.get("latitude", "-")}')
                print(f'  Longitude     >>> {loc.get("longitude", "-")}')
            print(f'{Nyellow}{"=" * 50}{VRCRM}')
            restart = input(f'\n{Hcyan}Outra consulta? S/N: {VRCRM}').strip().upper()[:1]
            clear()
