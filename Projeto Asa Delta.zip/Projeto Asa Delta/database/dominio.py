# -*- coding: utf-8 -*-
Ired='\033[1;31m'; Dgreen='\033[1;32m'; Nyellow='\033[1;33m'
Hcyan='\033[1;36m'; Iblue='\033[1;34m'; VRCRM='\033[0;0m'
import os, requests
from database.frases import get as frase

def clear(): os.system('cls' if os.name == 'nt' else 'clear')

def consultar():
    clear()
    print(f'\n{Iblue}{"=" * 50}')
    print(f'           WHOIS DOMINIO .BR')
    print(f'{Iblue}{"=" * 50}{VRCRM}')
    restart = 'S'
    while restart == 'S':
        dom = input(f'\n{Hcyan}Dominio (ex: google.com.br): {VRCRM}').strip().lower()
        try:
            r = requests.get(f'https://brasilapi.com.br/api/registrobr/v1/{dom}', timeout=10)
            rj = r.json()
        except Exception as e:
            print(f'{Ired}Erro: {e}')
            restart = input(f'\n{Hcyan}Tentar novamente? S/N: {VRCRM}').strip().upper()[:1]
            clear(); continue
        if r.status_code != 200 or rj.get('status_code') == 2:
            print(f'\n{Nyellow}{"=" * 50}')
            print(f'{Dgreen}  ==> DOMINIO DISPONIVEL <==')
            print(f'{Nyellow}{"=" * 50}{VRCRM}')
            print(f'  Dominio  >>> {dom}')
            print(f'  Status   >>> LIVRE - pode ser registrado')
            print(f'{Nyellow}{"=" * 50}{VRCRM}')
        else:
            print(f'\n{Nyellow}{"=" * 50}')
            print(f'{Dgreen}  ==> WHOIS ENCONTRADO <==')
            print(f'{Ired}  {frase()}')
            print(f'{Nyellow}{"=" * 50}{VRCRM}')
            print(f'  Dominio       >>> {rj.get("fqdn",dom)}')
            print(f'  Status        >>> {rj.get("status","N/A")}')
            print(f'  Titular       >>> {rj.get("owner","N/A")}')
            print(f'  Doc Titular   >>> {rj.get("owner-c","N/A")}')
            print(f'  Criado        >>> {rj.get("created","N/A")}')
            print(f'  Atualizado    >>> {rj.get("changed","N/A")}')
            print(f'  Expira        >>> {rj.get("expires","N/A")}')
            print(f'  Provedores:')
            for ns in rj.get('nameservers',[]):
                print(f'    - {ns}')
            print(f'{Nyellow}{"=" * 50}{VRCRM}')
        restart = input(f'\n{Hcyan}Outra consulta? S/N: {VRCRM}').strip().upper()[:1]
        clear()
