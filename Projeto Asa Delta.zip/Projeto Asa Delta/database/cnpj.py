# -*- coding: utf-8 -*-
Ired='\033[1;31m'; Dgreen='\033[1;32m'; Nyellow='\033[1;33m'
Hcyan='\033[1;36m'; Iblue='\033[1;34m'; VRCRM='\033[0;0m'
import os, requests, re
from database.frases import get as frase

def clear(): os.system('cls' if os.name == 'nt' else 'clear')

def consultar():
    clear()
    print(f'\n{Iblue}{"=" * 50}')
    print(f'              CONSULTA CNPJ')
    print(f'{Iblue}{"=" * 50}{VRCRM}')
    restart = 'S'
    while restart == 'S':
        while True:
            cnpj_input = re.sub(r'\D', '', input(f'\n{Hcyan}CNPJ (somente numeros): {VRCRM}').strip())
            if len(cnpj_input) != 14:
                print(f'{Ired}!!! CNPJ Invalido (14 digitos) !!!')
            else:
                break
        try:
            r = requests.get(f'https://brasilapi.com.br/api/cnpj/v1/{cnpj_input}', timeout=10)
            rj = r.json()
        except Exception as e:
            print(f'{Ired}Erro de conexao: {e}')
            restart = input(f'\n{Hcyan}Tentar novamente? S/N: {VRCRM}').strip().upper()[:1]
            clear(); continue

        if r.status_code != 200 or 'message' in rj:
            restart = input(f'{Ired}==> CNPJ NAO ENCONTRADO <==\n\n{Hcyan}Outra consulta? S/N: {VRCRM}').strip().upper()[:1]
            clear()
        else:
            print(f'\n{Nyellow}{"=" * 50}')
            print(f'{Dgreen}  ==> CNPJ ENCONTRADO <==')
            print(f'{Ired}  {frase()}')
            print(f'{Nyellow}{"=" * 50}{VRCRM}')
            print(f'  CNPJ          >>> {rj.get("cnpj", "-")}')
            print(f'  Razao Social  >>> {rj.get("razao_social", "-")}')
            print(f'  Nome Fantasia >>> {rj.get("nome_fantasia", "-") or "-"}')
            print(f'  Situacao      >>> {rj.get("descricao_situacao_cadastral", "-")}')
            print(f'  Data Abertura >>> {rj.get("data_inicio_atividade", "-")}')
            print(f'  Capital Soc   >>> R$ {rj.get("capital_social", "-")}')
            print(f'  Porte         >>> {rj.get("porte", "-")}')
            print(f'  Logradouro    >>> {rj.get("logradouro", "-")}, {rj.get("numero", "-")}')
            print(f'  Cidade        >>> {rj.get("municipio", "-")} - {rj.get("uf", "-")}')
            print(f'  CEP           >>> {rj.get("cep", "-")}')
            print(f'  Telefone      >>> {rj.get("ddd_telefone_1", "-")}')
            print(f'{Nyellow}{"=" * 50}{VRCRM}')
            restart = input(f'\n{Hcyan}Outra consulta? S/N: {VRCRM}').strip().upper()[:1]
            clear()
