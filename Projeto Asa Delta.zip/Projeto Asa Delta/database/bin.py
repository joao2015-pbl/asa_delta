# -*- coding: utf-8 -*-
Ired='\033[1;31m'; Dgreen='\033[1;32m'; Nyellow='\033[1;33m'
Hcyan='\033[1;36m'; Iblue='\033[1;34m'; VRCRM='\033[0;0m'
import os, requests
from database.frases import get as frase

def clear(): os.system('cls' if os.name == 'nt' else 'clear')

def consultar():
    clear()
    print(f'\n{Iblue}{"=" * 50}')
    print(f'           CONSULTA BIN CARTAO')
    print(f'{Iblue}{"=" * 50}{VRCRM}')
    restart = 'S'
    while restart == 'S':
        while True:
            b = input(f'\n{Hcyan}BIN (primeiros 6 digitos do cartao): {VRCRM}').strip()
            if not b.isdigit() or len(b) < 6:
                print(f'{Ired}!!! BIN invalido (minimo 6 digitos) !!!')
            else:
                b = b[:6]; break
        try:
            r = requests.get(f'https://brasilapi.com.br/api/banks/v1', timeout=8)
            rb = requests.get(f'https://lookup.binlist.net/{b}', headers={'Accept-Version':'3'}, timeout=8)
            rj = rb.json()
        except Exception as e:
            print(f'{Ired}Erro: {e}')
            restart = input(f'\n{Hcyan}Tentar novamente? S/N: {VRCRM}').strip().upper()[:1]
            clear(); continue
        if rb.status_code != 200:
            restart = input(f'{Ired}==> BIN NAO ENCONTRADO <==\n\n{Hcyan}Outra consulta? S/N: {VRCRM}').strip().upper()[:1]
            clear()
        else:
            print(f'\n{Nyellow}{"=" * 50}')
            print(f'{Dgreen}  ==> BIN ENCONTRADO <==')
            print(f'{Ired}  {frase()}')
            print(f'{Nyellow}{"=" * 50}{VRCRM}')
            print(f'  BIN           >>> {b}')
            print(f'  Esquema       >>> {rj.get("scheme","N/A").upper()}')
            print(f'  Tipo          >>> {rj.get("type","N/A").upper()}')
            print(f'  Categoria     >>> {rj.get("category","N/A")}')
            banco = rj.get("bank", {})
            print(f'  Banco         >>> {banco.get("name","N/A")}')
            print(f'  Telefone Bco  >>> {banco.get("phone","N/A")}')
            print(f'  Site Banco    >>> {banco.get("url","N/A")}')
            pais = rj.get("country", {})
            print(f'  Pais          >>> {pais.get("name","N/A")} ({pais.get("alpha2","N/A")})')
            print(f'  Moeda         >>> {pais.get("currency","N/A")}')
            print(f'{Nyellow}{"=" * 50}{VRCRM}')
            restart = input(f'\n{Hcyan}Outra consulta? S/N: {VRCRM}').strip().upper()[:1]
            clear()
