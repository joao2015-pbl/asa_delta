# -*- coding: utf-8 -*-
Ired='\033[1;31m'; Dgreen='\033[1;32m'; Nyellow='\033[1;33m'
Hcyan='\033[1;36m'; Iblue='\033[1;34m'; VRCRM='\033[0;0m'
import os, requests, re
from database.frases import get as frase

def clear(): os.system('cls' if os.name == 'nt' else 'clear')

def consultar():
    clear()
    print(f'\n{Iblue}{"=" * 50}')
    print(f'              CONSULTA PLACA')
    print(f'{Iblue}{"=" * 50}{VRCRM}')
    restart = 'S'
    while restart == 'S':
        while True:
            placa_input = re.sub(r'[-\s]', '', input(f'\n{Hcyan}Placa (ex: ABC1234): {VRCRM}').strip().upper())
            if len(placa_input) != 7:
                print(f'{Ired}!!! Placa Invalida (7 caracteres) !!!')
            else:
                break
        try:
            r = requests.get(f'https://apicarros.com/v1/consulta/{placa_input}/json', timeout=8)
            if r.status_code == 200:
                rj = r.json()
                if 'erro' not in rj and rj.get('placa'):
                    print(f'\n{Nyellow}{"=" * 50}')
                    print(f'{Dgreen}  ==> PLACA ENCONTRADA <==')
                    print(f'{Ired}  {frase()}')
                    print(f'{Nyellow}{"=" * 50}{VRCRM}')
                    print(f'  Placa         >>> {rj.get("placa", "-")}')
                    print(f'  Marca/Modelo  >>> {rj.get("marca", "-")} / {rj.get("modelo", "-")}')
                    print(f'  Ano           >>> {rj.get("ano", "-")} / {rj.get("anoModelo", "-")}')
                    print(f'  Cor           >>> {rj.get("cor", "-")}')
                    print(f'  Municipio     >>> {rj.get("municipio", "-")}')
                    print(f'  Situacao      >>> {rj.get("situacao", "-")}')
                    print(f'{Nyellow}{"=" * 50}{VRCRM}')
                    restart = input(f'\n{Hcyan}Outra consulta? S/N: {VRCRM}').strip().upper()[:1]
                    clear(); continue
        except: pass
        print(f'{Ired}  Consulta de placa indisponivel no momento.{VRCRM}')
        restart = input(f'\n{Hcyan}Tentar novamente? S/N: {VRCRM}').strip().upper()[:1]
        clear()
