# -*- coding: utf-8 -*-
Ired='\033[1;31m'; Dgreen='\033[1;32m'; Nyellow='\033[1;33m'
Hcyan='\033[1;36m'; Iblue='\033[1;34m'; VRCRM='\033[0;0m'
import os, socket
from concurrent.futures import ThreadPoolExecutor, as_completed

def clear(): os.system('cls' if os.name == 'nt' else 'clear')

PORTAS = {
    21:   'FTP',
    22:   'SSH',
    23:   'Telnet',
    25:   'SMTP',
    53:   'DNS',
    80:   'HTTP',
    110:  'POP3',
    135:  'RPC',
    139:  'NetBIOS',
    143:  'IMAP',
    443:  'HTTPS',
    445:  'SMB',
    1433: 'MSSQL',
    1521: 'Oracle DB',
    3306: 'MySQL',
    3389: 'RDP (Remote Desktop)',
    5432: 'PostgreSQL',
    5900: 'VNC',
    6379: 'Redis',
    8080: 'HTTP Alt',
    8443: 'HTTPS Alt',
    8888: 'Jupyter/HTTP Alt',
    27017:'MongoDB',
}

def checar_porta(host, porta, timeout=1.0):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        resultado = s.connect_ex((host, porta))
        s.close()
        return porta, resultado == 0
    except:
        return porta, False

def consultar():
    clear()
    print(f'\n{Ired}{"=" * 52}')
    print(f'              SCAN DE PORTAS')
    print(f'{Ired}{"=" * 52}{VRCRM}')
    print(f'  {Nyellow}[1]{VRCRM} Scan rapido (portas conhecidas)')
    print(f'  {Nyellow}[2]{VRCRM} Scan de range personalizado')
    modo = input(f'\n{Hcyan}Opcao: {VRCRM}').strip()
    clear()

    alvo = input(f'\n{Hcyan}IP ou host alvo: {VRCRM}').strip()
    print(f'\n{Nyellow}  Resolvendo host...')
    try:
        ip_resolvido = socket.gethostbyname(alvo)
        print(f'  Host: {ip_resolvido}{VRCRM}')
    except:
        print(f'{Ired}  Nao foi possivel resolver o host.{VRCRM}')
        input(f'\n{Hcyan}[ ENTER ]{VRCRM}'); clear(); return

    abertas = []

    if modo == '1':
        portas_alvo = list(PORTAS.keys())
        print(f'\n{Nyellow}  Varrendo {len(portas_alvo)} portas conhecidas...{VRCRM}\n')
        with ThreadPoolExecutor(max_workers=50) as ex:
            futures = {ex.submit(checar_porta, ip_resolvido, p): p for p in portas_alvo}
            for fut in as_completed(futures):
                porta, aberta = fut.result()
                servico = PORTAS.get(porta, '')
                if aberta:
                    abertas.append((porta, servico))
                    print(f'  {Dgreen}[ABERTA]{VRCRM}  {porta:<6} {servico}')
    else:
        try:
            inicio = int(input(f'\n{Hcyan}Porta inicio: {VRCRM}').strip())
            fim    = int(input(f'{Hcyan}Porta fim:    {VRCRM}').strip())
            if fim - inicio > 5000:
                print(f'{Nyellow}  Limitando a 5000 portas por vez.{VRCRM}')
                fim = inicio + 5000
        except:
            print(f'{Ired}Range invalido.{VRCRM}')
            input(f'\n{Hcyan}[ ENTER ]{VRCRM}'); clear(); return
        print(f'\n{Nyellow}  Varrendo portas {inicio}-{fim}...{VRCRM}\n')
        with ThreadPoolExecutor(max_workers=100) as ex:
            futures = {ex.submit(checar_porta, ip_resolvido, p): p for p in range(inicio, fim+1)}
            for fut in as_completed(futures):
                porta, aberta = fut.result()
                if aberta:
                    servico = PORTAS.get(porta, 'desconhecido')
                    abertas.append((porta, servico))
                    print(f'  {Dgreen}[ABERTA]{VRCRM}  {porta:<6} {servico}')

    print(f'\n{Nyellow}{"=" * 52}')
    print(f'{Dgreen if abertas else Ired}  {len(abertas)} porta(s) abertas encontradas')
    print(f'{Nyellow}{"=" * 52}{VRCRM}')
    if abertas:
        for p, s in sorted(abertas):
            print(f'  {Dgreen}{p:<6}{VRCRM} {s}')
    input(f'\n{Hcyan}[ ENTER para voltar ]{VRCRM}')
    clear()
