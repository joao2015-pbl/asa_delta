# -*- coding: utf-8 -*-
Ired='\033[1;31m'; Dgreen='\033[1;32m'; Nyellow='\033[1;33m'
Hcyan='\033[1;36m'; Iblue='\033[1;34m'; VRCRM='\033[0;0m'
import os, ctypes, sys
from database.frases import get as frase

def clear(): os.system('cls' if os.name == 'nt' else 'clear')

def consultar():
    clear()
    print(f'\n{Iblue}{"=" * 50}')
    print(f'               ADMIN CHECKER')
    print(f'{Iblue}{"=" * 50}{VRCRM}')
    try:
        is_admin = ctypes.windll.shell32.IsUserAnAdmin() if os.name == 'nt' else (os.getuid() == 0)
    except:
        is_admin = False
    print(f'\n{Nyellow}{"=" * 50}')
    if is_admin:
        print(f'{Dgreen}  [+] ADMINISTRADOR / ROOT DETECTADO')
    else:
        print(f'{Ired}  [-] sem privilegios elevados.')
    print(f'{Ired}  {frase()}')
    print(f'{Nyellow}{"=" * 50}{VRCRM}')
    input(f'\n{Hcyan}[ ENTER para voltar ]{VRCRM}')
    clear()
