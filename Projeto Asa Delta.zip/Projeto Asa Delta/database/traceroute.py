# -*- coding: utf-8 -*-
Ired='\033[1;31m'; Dgreen='\033[1;32m'; Nyellow='\033[1;33m'
Hcyan='\033[1;36m'; Iblue='\033[1;34m'; VRCRM='\033[0;0m'
import os, subprocess, platform, socket, requests

def clear(): os.system('cls' if os.name == 'nt' else 'clear')

def geo_hop(ip):
    try:
        r = requests.get(f'http://ip-api.com/json/{ip}?fields=country,city,isp,status', timeout=3)
        rj = r.json()
        if rj.get('status') == 'success':
            return f'{rj.get("city","?")} - {rj.get("country","?")} | {rj.get("isp","?")}'
    except: pass
    return ''

def consultar():
    clear()
    print(f'\n{Iblue}{"=" * 52}')
    print(f'               TRACEROUTE')
    print(f'{Iblue}{"=" * 52}{VRCRM}')
    alvo = input(f'\n{Hcyan}IP ou host: {VRCRM}').strip()
    print(f'\n{Nyellow}  Executando traceroute para {alvo}...{VRCRM}\n')
    print(f'  {Nyellow}{"HOP":<5} {"IP":<18} {"LOCALIZACAO"}{VRCRM}')
    print(f'  {'-'*50}')

    sistema = platform.system().lower()
    if 'windows' in sistema:
        cmd = ['tracert', '-d', '-h', '20', alvo]
    else:
        cmd = ['traceroute', '-n', '-m', '20', alvo]

    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                text=True, encoding='utf-8', errors='ignore')
        hop = 0
        for line in proc.stdout:
            line = line.strip()
            if not line: continue
            # Extrai IPs da linha
            import re
            ips = re.findall(r'\b(?:\d{1,3}\.){3}\d{1,3}\b', line)
            numeros = re.findall(r'^\s*(\d+)', line)
            if ips and numeros:
                hop = numeros[0]
                ip  = ips[0]
                geo = geo_hop(ip)
                cor = Dgreen if geo else Nyellow
                print(f'  {Nyellow}{hop:<5}{VRCRM} {cor}{ip:<18}{VRCRM} {geo}')
            elif '*' in line and numeros:
                hop = numeros[0]
                print(f'  {Nyellow}{hop:<5}{VRCRM} {Ired}{"* * *":<18}{VRCRM} timeout')
        proc.wait()
    except FileNotFoundError:
        print(f'{Ired}  tracert/traceroute nao encontrado no sistema.')
        print(f'  Windows: ja vem instalado. Linux: apt install traceroute{VRCRM}')
    except Exception as e:
        print(f'{Ired}  Erro: {e}{VRCRM}')

    print(f'\n{Nyellow}{"=" * 52}{VRCRM}')
    input(f'\n{Hcyan}[ ENTER para voltar ]{VRCRM}')
    clear()
