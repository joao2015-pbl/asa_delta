# -*- coding: utf-8 -*-
Ired='\033[1;31m'; Dgreen='\033[1;32m'; Nyellow='\033[1;33m'
Hcyan='\033[1;36m'; Iblue='\033[1;34m'; VRCRM='\033[0;0m'
import os, requests
from database.frases import get as frase

def clear(): os.system('cls' if os.name == 'nt' else 'clear')

def consultar():
    clear()
    print(f'\n{Iblue}{"=" * 50}')
    print(f'              CONSULTA BANCO')
    print(f'{Iblue}{"=" * 50}{VRCRM}')
    print(f'  {Nyellow}[1]{VRCRM} Buscar por codigo ISPB/codigo')
    print(f'  {Nyellow}[2]{VRCRM} Listar todos os bancos')
    modo = input(f'\n{Hcyan}Opcao: {VRCRM}').strip()
    clear()

    if modo == '1':
        cod = input(f'\n{Hcyan}Codigo do banco (ex: 001 = BB, 341 = Itau): {VRCRM}').strip()
        try:
            r = requests.get(f'https://brasilapi.com.br/api/banks/v1/{cod}', timeout=8)
            rj = r.json()
        except Exception as e:
            print(f'{Ired}Erro: {e}{VRCRM}'); return
        if r.status_code != 200:
            print(f'{Ired}Banco nao encontrado.{VRCRM}')
        else:
            print(f'\n{Nyellow}{"=" * 50}')
            print(f'{Dgreen}  ==> BANCO ENCONTRADO <==')
            print(f'{Ired}  {frase()}')
            print(f'{Nyellow}{"=" * 50}{VRCRM}')
            print(f'  Codigo        >>> {rj.get("code","N/A")}')
            print(f'  ISPB          >>> {rj.get("ispb","N/A")}')
            print(f'  Nome          >>> {rj.get("name","N/A")}')
            print(f'  Nome Completo >>> {rj.get("fullName","N/A")}')
            print(f'{Nyellow}{"=" * 50}{VRCRM}')
    else:
        try:
            r = requests.get('https://brasilapi.com.br/api/banks/v1', timeout=10)
            bancos = [b for b in r.json() if b.get('code')]
            bancos.sort(key=lambda x: int(x.get('code') or 9999))
        except Exception as e:
            print(f'{Ired}Erro: {e}{VRCRM}'); return
        busca = input(f'\n{Hcyan}Filtrar por nome (ENTER pra listar todos): {VRCRM}').strip().lower()
        print(f'\n{Nyellow}{"=" * 50}{VRCRM}')
        count = 0
        for b in bancos:
            nome = (b.get('name') or '').lower()
            if busca and busca not in nome: continue
            print(f'  {Nyellow}{str(b.get("code","")).zfill(3)}{VRCRM}  {b.get("name","N/A")}')
            count += 1
        print(f'\n{Dgreen}  {count} banco(s) encontrado(s){VRCRM}')
        print(f'{Nyellow}{"=" * 50}{VRCRM}')
    input(f'\n{Hcyan}[ ENTER para voltar ]{VRCRM}')
    clear()
