# -*- coding: utf-8 -*-
Ired='\033[1;31m'; Dgreen='\033[1;32m'; Nyellow='\033[1;33m'
Hcyan='\033[1;36m'; Iblue='\033[1;34m'; Gpurple='\033[1;35m'; VRCRM='\033[0;0m'
import os, requests, socket
from datetime import datetime
from database.frases import get as frase

def clear(): os.system('cls' if os.name == 'nt' else 'clear')

def secao(titulo, dados):
    linhas = [f'\n{"=" * 54}', f'  {titulo}', f'{"=" * 54}']
    for k, v in dados:
        linhas.append(f'  {k:<22}: {v}')
    return '\n'.join(linhas)

def consultar():
    clear()
    print(f'\n{Gpurple}{"=" * 52}')
    print(f'            GERAR RELATORIO .TXT')
    print(f'{Gpurple}{"=" * 52}{VRCRM}')
    print(f'\n  Informe os dados que voce tem sobre o alvo.')
    print(f'  Deixe em branco para pular.\n')

    alvo_nome = input(f'{Hcyan}Nome/apelido do alvo: {VRCRM}').strip() or 'Desconhecido'
    ip_input  = input(f'{Hcyan}IP do alvo:           {VRCRM}').strip()
    num_input = input(f'{Hcyan}Numero (DDD+numero):  {VRCRM}').strip()
    cep_input = input(f'{Hcyan}CEP:                  {VRCRM}').strip().replace('-','')
    usr_input = input(f'{Hcyan}Username:             {VRCRM}').strip()
    email_in  = input(f'{Hcyan}Email:                {VRCRM}').strip()

    print(f'\n{Nyellow}  Coletando dados, aguarde...{VRCRM}')
    conteudo  = []
    cabecalho = [
        f'MENTA NUKER - RELATORIO DE ALVO',
        f'Gerado em: {datetime.now().strftime("%d/%m/%Y %H:%M:%S")}',
        f'Alvo: {alvo_nome}',
        f'{"=" * 54}',
        f'"{frase()}"',
    ]
    conteudo.append('\n'.join(cabecalho))

    # IP
    if ip_input:
        try:
            r = requests.get(f'http://ip-api.com/json/{ip_input}', timeout=6)
            rj = r.json()
            if rj.get('status') == 'success':
                conteudo.append(secao('IP GEOLOCALIZACAO', [
                    ('IP', rj.get('query','-')),
                    ('Pais', rj.get('country','-')),
                    ('Regiao', rj.get('regionName','-')),
                    ('Cidade', rj.get('city','-')),
                    ('Provedor', rj.get('isp','-')),
                    ('Organizacao', rj.get('org','-')),
                    ('Latitude', str(rj.get('lat','-'))),
                    ('Longitude', str(rj.get('lon','-'))),
                    ('Fuso', rj.get('timezone','-')),
                ]))
        except: pass

    # CEP
    if cep_input:
        try:
            r = requests.get(f'https://brasilapi.com.br/api/cep/v2/{cep_input}', timeout=6)
            rj = r.json()
            if r.status_code == 200:
                conteudo.append(secao('ENDERECO (CEP)', [
                    ('CEP', rj.get('cep','-')),
                    ('Logradouro', rj.get('street','-')),
                    ('Bairro', rj.get('neighborhood','-')),
                    ('Cidade', rj.get('city','-')),
                    ('Estado', rj.get('state','-')),
                ]))
        except: pass

    # Numero
    if num_input:
        try:
            import phonenumbers
            from phonenumbers import carrier, geocoder, number_type, PhoneNumberType
            num_clean = '+55' + num_input.lstrip('0') if not num_input.startswith('+') else num_input
            parsed = phonenumbers.parse(num_clean, None)
            tipo_raw = number_type(parsed)
            tipo_map = {PhoneNumberType.MOBILE:'Celular', PhoneNumberType.FIXED_LINE:'Fixo'}
            conteudo.append(secao('NUMERO', [
                ('Numero', phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.INTERNATIONAL)),
                ('Valido', 'Sim' if phonenumbers.is_valid_number(parsed) else 'Nao'),
                ('Tipo', tipo_map.get(tipo_raw, 'Desconhecido')),
                ('Operadora', carrier.name_for_number(parsed,'pt') or 'N/A'),
                ('Regiao', geocoder.description_for_number(parsed,'pt') or 'N/A'),
            ]))
        except: pass

    # Username
    if usr_input:
        from concurrent.futures import ThreadPoolExecutor, as_completed
        import requests as req
        SITES = {
            'GitHub':    'https://github.com/{}',
            'Instagram': 'https://www.instagram.com/{}/',
            'Twitter/X': 'https://twitter.com/{}',
            'TikTok':    'https://www.tiktok.com/@{}',
            'Reddit':    'https://www.reddit.com/user/{}/',
            'Twitch':    'https://www.twitch.tv/{}',
            'Steam':     'https://steamcommunity.com/id/{}/',
            'YouTube':   'https://www.youtube.com/@{}',
        }
        hdrs = {'User-Agent': 'Mozilla/5.0'}
        achou = []
        def chk(nome, url_t):
            try:
                r = req.get(url_t.format(usr_input), headers=hdrs, timeout=5)
                if r.status_code == 200: return (nome, url_t.format(usr_input))
            except: pass
            return None
        with ThreadPoolExecutor(max_workers=8) as ex:
            futs = [ex.submit(chk, n, u) for n,u in SITES.items()]
            for f in as_completed(futs):
                res = f.result()
                if res: achou.append(res)
        if achou:
            conteudo.append(secao('USERNAME OSINT (@' + usr_input + ')',
                                  [(n, u) for n,u in sorted(achou)]))

    # Email
    if email_in:
        try:
            r = requests.get(f'https://emailrep.io/{email_in}', timeout=6,
                             headers={'User-Agent':'Mozilla/5.0'})
            if r.status_code == 200:
                rj = r.json()
                d  = rj.get('details', {})
                conteudo.append(secao('EMAIL OSINT', [
                    ('Email', email_in),
                    ('Reputacao', rj.get('reputation','N/A')),
                    ('Suspeito', 'Sim' if rj.get('suspicious') else 'Nao'),
                    ('Vazamento', 'Sim' if d.get('data_breach') else 'Nao'),
                    ('Perfis', ', '.join(d.get('profiles',['nenhum']))),
                ]))
        except: pass

    # Salva arquivo
    nome_arquivo = f'relatorio_{alvo_nome.replace(" ","_")}_{datetime.now().strftime("%d%m%Y_%H%M%S")}.txt'
    caminho = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), nome_arquivo)
    with open(caminho, 'w', encoding='utf-8') as arq:
        arq.write('\n\n'.join(conteudo))

    print(f'\n{Dgreen}  Relatorio salvo em: {nome_arquivo}{VRCRM}')
    print(f'{Nyellow}{"=" * 52}{VRCRM}')
    input(f'\n{Hcyan}[ ENTER para voltar ]{VRCRM}')
    clear()
