# -*- coding: utf-8 -*-
Ired='\033[1;31m'; Dgreen='\033[1;32m'; Nyellow='\033[1;33m'
Hcyan='\033[1;36m'; Iblue='\033[1;34m'; Gpurple='\033[1;35m'; Twhite='\033[1;37m'; VRCRM='\033[0;0m'
import os, sys, time, re, subprocess, tempfile, requests
from bs4 import BeautifulSoup
from database.frases import get as frase

def clear(): os.system('cls' if os.name == 'nt' else 'clear')

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,*/*',
    'Accept-Language': 'en-US,en;q=0.9',
}

DDI_PAIS = {
    '1':'United States/Canada','7':'Russia','20':'Egypt','27':'South Africa',
    '30':'Greece','31':'Netherlands','32':'Belgium','33':'France','34':'Spain',
    '36':'Hungary','39':'Italy','40':'Romania','41':'Switzerland','43':'Austria',
    '44':'United Kingdom','45':'Denmark','46':'Sweden','47':'Norway','48':'Poland',
    '49':'Germany','51':'Peru','52':'Mexico','54':'Argentina','55':'Brazil',
    '56':'Chile','57':'Colombia','358':'Finland','380':'Ukraine','381':'Serbia',
    '420':'Czech Republic','60':'Malaysia','61':'Australia','62':'Indonesia',
    '63':'Philippines','66':'Thailand','81':'Japan','82':'South Korea',
    '84':'Vietnam','86':'China','90':'Turkey','91':'India','92':'Pakistan','98':'Iran',
}

def detectar_pais(numero):
    n = numero.lstrip('+')
    for ddi in sorted(DDI_PAIS, key=len, reverse=True):
        if n.startswith(ddi):
            return DDI_PAIS[ddi]
    return 'Outro'

def buscar_numeros():
    try:
        r = requests.get('https://sms24.me/en/numbers/', headers=HEADERS, timeout=10)
        nums_raw = re.findall(r'\+(\d{10,15})', r.text)
        vistos, res = set(), []
        for n in nums_raw:
            num = '+' + n
            if num not in vistos:
                vistos.add(num)
                res.append({'numero': num, 'pais': detectar_pais(num)})
        return res
    except:
        return []

def buscar_sms(numero):
    num_limpo = numero.lstrip('+')
    url = f'https://sms24.me/en/numbers/{num_limpo}/'
    try:
        r = requests.get(url, headers=HEADERS, timeout=10)
        soup = BeautifulSoup(r.text, 'html.parser')
        dds, dts, msgs = soup.select('dd'), soup.select('dt'), []
        for i, dd in enumerate(dds):
            lbl  = dd.select_one('label a')
            span = dd.select_one('span.placeholder, span[class*="text-break"]')
            if not lbl or not span: continue
            rem  = lbl.get('title','').replace('SMS From ','').strip()
            if not rem: rem = re.sub(r'^From:\s*','', lbl.get_text(strip=True))
            txt  = span.get_text(' ', strip=True)
            if not txt: continue
            data = 'N/A'
            if i < len(dts):
                d = dts[i].select_one('[data-created]')
                if d: data = d.get('data-created','N/A')[:19].replace('T',' ')
            msgs.append({'de': rem or '?', 'texto': txt, 'data': data})
        return msgs
    except:
        return []

def criar_monitor(numero):
    num_limpo = numero.lstrip('+')
    pais      = detectar_pais(numero)
    sms_url   = f'https://sms24.me/en/numbers/{num_limpo}/'
    # Escreve o script do monitor como string simples
    linhas = [
        '# -*- coding: utf-8 -*-',
        'import os, sys, time, re, requests, atexit',
        'from bs4 import BeautifulSoup',
        '',
        '_PATH = __file__',
        'atexit.register(lambda: os.path.exists(_PATH) and os.unlink(_PATH))',
        '',
        'RED=\"\\033[1;31m\"; GREEN=\"\\033[1;32m\"; YELLOW=\"\\033[1;33m\"',
        'CYAN=\"\\033[1;36m\"; WHITE=\"\\033[1;37m\"; RESET=\"\\033[0;0m\"',
        f'NUMERO="{numero}"',
        f'PAIS="{pais}"',
        f'URL="{sms_url}"',
        'HDR={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}',
        '',
        'def clear(): os.system("cls" if os.name=="nt" else "clear")',
        '',
        'def buscar():',
        '    try:',
        '        r=requests.get(URL,headers=HDR,timeout=10)',
        '        soup=BeautifulSoup(r.text,"html.parser")',
        '        dds=soup.select("dd"); dts=soup.select("dt"); msgs=[]',
        '        for i,dd in enumerate(dds):',
        '            lbl=dd.select_one("label a")',
        '            span=dd.select_one("span.placeholder,span[class*=text-break]")',
        '            if not lbl or not span: continue',
        '            rem=lbl.get("title","").replace("SMS From ","").strip()',
        '            if not rem: rem=re.sub(r"^From:\\s*","",lbl.get_text(strip=True))',
        '            txt=span.get_text(" ",strip=True)',
        '            if not txt: continue',
        '            data="N/A"',
        '            if i<len(dts):',
        '                d=dts[i].select_one("[data-created]")',
        '                if d: data=d.get("data-created","N/A")[:19].replace("T"," ")',
        '            msgs.append({"de":rem or "?","texto":txt,"data":data})',
        '        return msgs',
        '    except: return []',
        '',
        'def exibir(msgs):',
        '    clear()',
        '    sep="="*60',
        '    print(f"\\n{RED}{sep}{RESET}")',
        '    print(f"  {YELLOW}NUMERO  {WHITE}{NUMERO}{RESET}")',
        '    print(f"  {YELLOW}PAIS    {WHITE}{PAIS}{RESET}")',
        '    print(f"{RED}{sep}{RESET}\\n")',
        '    if not msgs:',
        '        print(f"{CYAN}  Sem SMS ainda. Aguardando...{RESET}")',
        '    else:',
        '        print(f"{GREEN}  {len(msgs)} SMS recebido(s):\\n{RESET}")',
        '        for i,m in enumerate(msgs,1):',
        '            print(f"{YELLOW}  [{i}] De   : {WHITE}{m[\\"de\\"]}{RESET}")',
        '            print(f"{YELLOW}      Data : {WHITE}{m[\\"data\\"]}{RESET}")',
        '            print(f"{YELLOW}      Texto: {GREEN}{m[\\"texto\\"]}{RESET}")',
        '            print(f"{RED}  {chr(45)*55}{RESET}")',
        '    print(f"\\n{CYAN}  Atualizando em 5s... Ctrl+C para fechar{RESET}")',
        '',
        'print("\\n  Monitor iniciando...")',
        'try:',
        '    while True:',
        '        exibir(buscar())',
        '        time.sleep(5)',
        'except KeyboardInterrupt:',
        '    print("\\n\\n  Monitor encerrado. Arquivo removido.")',
        '    time.sleep(1)',
    ]
    tmp = tempfile.NamedTemporaryFile(
        mode='w', suffix='_mnk_sms.py', delete=False,
        encoding='utf-8', prefix='tmp_'
    )
    tmp.write('\n'.join(linhas))
    tmp.close()
    return tmp.name

def abrir_janela(script_path):
    py = sys.executable
    try:
        if os.name == 'nt':
            try:
                subprocess.Popen(
                    ['powershell','-NoExit','-Command',f'& "{py}" "{script_path}"'],
                    creationflags=subprocess.CREATE_NEW_CONSOLE
                )
            except FileNotFoundError:
                subprocess.Popen(
                    ['cmd','/k',f'"{py}" "{script_path}"'],
                    creationflags=subprocess.CREATE_NEW_CONSOLE
                )
        else:
            for cmd in [
                ['gnome-terminal','--',py,script_path],
                ['xterm','-e',py,script_path],
                ['konsole','-e',py,script_path],
            ]:
                try: subprocess.Popen(cmd); return True
                except FileNotFoundError: continue
            subprocess.Popen([py,script_path])
        return True
    except Exception as e:
        print(f'{Ired}Erro: {e}{VRCRM}'); return False

def consultar():
    clear()
    print(f'\n{Iblue}{"="*56}')
    print(f'         NUMERO TEMPORARIO + SMS MONITOR')
    print(f'{Iblue}{"="*56}{VRCRM}')
    print(f'\n{Nyellow}  Buscando numeros em sms24.me...{VRCRM}')

    numeros = buscar_numeros()
    if not numeros:
        print(f'\n{Ired}  [!] Falha ao buscar numeros. Verifique conexao.{VRCRM}')
        input(f'\n{Hcyan}[ ENTER ]{VRCRM}'); return

    paises_disp = sorted(set(n['pais'] for n in numeros))
    clear()
    print(f'\n{Iblue}{"="*56}')
    print(f'              ESCOLHA O PAIS')
    print(f'{Iblue}{"="*56}{VRCRM}')
    for i,p in enumerate(paises_disp,1):
        cnt = sum(1 for n in numeros if n['pais']==p)
        print(f'  {Nyellow}[{i:>2}]{VRCRM}  {Dgreen}{p:<30}{VRCRM} ({cnt})')
    print(f'\n  {Nyellow}[00]{VRCRM}  Todos')
    print(f'{Iblue}{"="*56}{VRCRM}')

    ep = input(f'\n{Hcyan}Opcao: {VRCRM}').strip().upper()
    if ep in ('','V'): return

    if ep == '00' or ep == '0':
        filtrados = numeros
    else:
        try:
            filtrados = [n for n in numeros if n['pais']==paises_disp[int(ep)-1]]
        except (ValueError,IndexError):
            filtrados = numeros

    clear()
    print(f'\n{Iblue}{"="*56}')
    print(f'           NUMEROS DISPONIVEIS')
    print(f'{Iblue}{"="*56}{VRCRM}')
    for i,n in enumerate(filtrados,1):
        print(f'  {Nyellow}[{i:>2}]{VRCRM}  {Dgreen}{n["numero"]:<22}{VRCRM} {n["pais"]}')
    print(f'\n  {Nyellow}[M]{VRCRM}  Digitar manualmente')
    print(f'{Iblue}{"="*56}{VRCRM}')

    en = input(f'\n{Hcyan}Numero: {VRCRM}').strip().upper()
    if en in ('','V'): return

    if en == 'M':
        numero = input(f'{Hcyan}(+DDI+numero): {VRCRM}').strip()
        if not numero: return
        if not numero.startswith('+'): numero = '+'+numero
    else:
        try:
            numero = filtrados[int(en)-1]['numero']
        except (ValueError,IndexError):
            print(f'{Ired}Invalido.{VRCRM}'); time.sleep(1); return

    clear()
    print(f'\n{Iblue}{"="*56}')
    print(f'  NUMERO : {Dgreen}{numero}{VRCRM}')
    print(f'  PAIS   : {Dgreen}{detectar_pais(numero)}{VRCRM}')
    print(f'{Iblue}{"="*56}{VRCRM}')
    print(f'\n{Nyellow}  Buscando SMS...{VRCRM}')

    msgs = buscar_sms(numero)
    if not msgs:
        print(f'\n{Hcyan}  Nenhum SMS recebido ainda.{VRCRM}')
    else:
        print(f'\n{Nyellow}{"="*56}')
        print(f'{Dgreen}  {len(msgs)} SMS encontrado(s)')
        print(f'{Ired}  {frase()}')
        print(f'{Nyellow}{"="*56}{VRCRM}')
        for i,m in enumerate(msgs[:5],1):
            print(f'  {Nyellow}[{i}] De    : {Twhite}{m["de"]}{VRCRM}')
            print(f'       Data  : {Twhite}{m["data"]}{VRCRM}')
            print(f'       Texto : {Dgreen}{m["texto"][:80]}{VRCRM}')
            print(f'  {Ired}{"-"*50}{VRCRM}')

    print(f'\n{Iblue}{"="*56}{VRCRM}')
    print(f'  {Nyellow}[1]{VRCRM} Nova janela {Dgreen}(5s refresh, auto-deleta ao fechar)')
    print(f'  {Nyellow}[2]{VRCRM} Monitorar aqui {Dgreen}(Ctrl+C para parar)')
    print(f'  {Nyellow}[0]{VRCRM} Voltar')
    print(f'{Iblue}{"="*56}{VRCRM}')

    acao = input(f'\n{Hcyan}Opcao: {VRCRM}').strip()

    if acao == '1':
        script = criar_monitor(numero)
        if abrir_janela(script):
            print(f'\n{Dgreen}  [+] Monitor aberto em nova janela!{VRCRM}')
            print(f'{Hcyan}  Numero : {Twhite}{numero}{VRCRM}')
            print(f'{Hcyan}  Refresh: {Twhite}5 segundos{VRCRM}')
            print(f'{Nyellow}  Arquivo temp deletado automaticamente ao fechar.{VRCRM}')
        else:
            print(f'{Ired}  Falha. Rode: python "{script}"{VRCRM}')
        input(f'\n{Hcyan}[ ENTER ]{VRCRM}')

    elif acao == '2':
        try:
            while True:
                m2 = buscar_sms(numero)
                clear()
                print(f'\n{Iblue}{"="*56}')
                print(f'  MONITOR  {Dgreen}{numero}{VRCRM}')
                print(f'{Iblue}{"="*56}{VRCRM}')
                if not m2:
                    print(f'\n{Hcyan}  Sem SMS. Aguardando...{VRCRM}')
                else:
                    for i,m in enumerate(m2,1):
                        print(f'  {Nyellow}[{i}] De    : {Twhite}{m["de"]}{VRCRM}')
                        print(f'       Data  : {Twhite}{m["data"]}{VRCRM}')
                        print(f'       Texto : {Dgreen}{m["texto"]}{VRCRM}')
                        print(f'  {Ired}{"-"*50}{VRCRM}')
                print(f'\n{Hcyan}  5s... Ctrl+C para sair{VRCRM}')
                time.sleep(5)
        except KeyboardInterrupt:
            pass
