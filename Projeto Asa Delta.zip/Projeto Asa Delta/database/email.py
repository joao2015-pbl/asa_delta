# -*- coding: utf-8 -*-
Ired='\033[1;31m'; Dgreen='\033[1;32m'; Nyellow='\033[1;33m'
Hcyan='\033[1;36m'; Iblue='\033[1;34m'; Gpurple='\033[1;35m'; VRCRM='\033[0;0m'
import os, requests
from database.frases import get as frase

def clear(): os.system('cls' if os.name == 'nt' else 'clear')

HEADERS = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}

def consultar():
    clear()
    print(f'\n{Iblue}{"=" * 52}')
    print(f'               EMAIL OSINT')
    print(f'{Iblue}{"=" * 52}{VRCRM}')
    restart = 'S'
    while restart == 'S':
        email = input(f'\n{Hcyan}Email: {VRCRM}').strip().lower()
        if '@' not in email:
            print(f'{Ired}!!! Email invalido !!!'); continue

        print(f'\n{Nyellow}  Analisando {email}...{VRCRM}')
        resultados = []

        # 1. emailrep.io — reputacao e vazamentos
        try:
            r = requests.get(f'https://emailrep.io/{email}', headers=HEADERS, timeout=8)
            if r.status_code == 200:
                rj = r.json()
                refs = rj.get('references', 0)
                rep  = rj.get('reputation', 'N/A')
                susp = rj.get('suspicious', False)
                profiles = rj.get('details', {}).get('profiles', [])
                breached = rj.get('details', {}).get('data_breach', False)
                malicious = rj.get('details', {}).get('malicious_activity', False)
                resultados.append(('Reputacao', rep))
                resultados.append(('Suspeito', 'SIM' if susp else 'nao'))
                resultados.append(('Referencias', str(refs)))
                resultados.append(('Vazamento', 'SIM' if breached else 'nao'))
                resultados.append(('Atividade maliciosa', 'SIM' if malicious else 'nao'))
                if profiles:
                    resultados.append(('Perfis detectados', ', '.join(profiles)))
        except: pass

        # 2. hunter.io domain check (free, sem key, verifica dominio do email)
        dominio = email.split('@')[1]
        try:
            r2 = requests.get(f'https://api.hunter.io/v2/domain-search?domain={dominio}&limit=5', timeout=8)
            if r2.status_code == 200:
                rj2 = r2.json()
                org = rj2.get('data', {}).get('organization', '')
                if org:
                    resultados.append(('Organizacao dominio', org))
        except: pass

        # 3. disposable email check
        try:
            r3 = requests.get(f'https://open.kickbox.com/v1/disposable/{email}', timeout=5)
            if r3.status_code == 200:
                disp = r3.json().get('disposable', False)
                resultados.append(('Email descartavel', 'SIM' if disp else 'nao'))
        except: pass

        print(f'\n{Nyellow}{"=" * 52}')
        print(f'{Dgreen}  ==> EMAIL ANALISADO <==')
        print(f'{Ired}  {frase()}')
        print(f'{Nyellow}{"=" * 52}{VRCRM}')
        print(f'  Email         >>> {email}')
        print(f'  Dominio       >>> {dominio}')
        for chave, valor in resultados:
            cor = Ired if valor in ('SIM', 'none', 'low') else Dgreen
            print(f'  {chave:<22}>>> {cor}{valor}{VRCRM}')
        if not resultados:
            print(f'  {Nyellow}Sem dados publicos encontrados para este email.{VRCRM}')
        print(f'{Nyellow}{"=" * 52}{VRCRM}')
        restart = input(f'\n{Hcyan}Outro email? S/N: {VRCRM}').strip().upper()[:1]
        clear()
