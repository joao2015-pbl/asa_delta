# -*- coding: utf-8 -*-
Ired='\033[1;31m'; Dgreen='\033[1;32m'; Nyellow='\033[1;33m'
Hcyan='\033[1;36m'; Iblue='\033[1;34m'; Gpurple='\033[1;35m'; VRCRM='\033[0;0m'
import os, random

def clear(): os.system('cls' if os.name == 'nt' else 'clear')

BASE = {
    # CEP
    ('cep','codigo postal','endereco','rua','bairro','logradouro','cep invalido','consulta cep'): [
        "manda o cep com 8 digitos, sem traco. ex: 01310100",
        "cep vai te dar rua, bairro, cidade, estado e coordenadas.",
        "so numeros, 8 digitos. sem espaco, sem traco.",
        "retorna logradouro, bairro, cidade, estado e lat/lon.",
        "usa brasilapi pra puxar. se nao achar e porque o cep nao existe.",
    ],
    # CNPJ
    ('cnpj','empresa','razao social','receita','cnpj invalido','cnpj nao encontrado','consulta cnpj'): [
        "cnpj e 14 digitos. pode colocar so os numeros mesmo.",
        "traz razao social, situacao, capital, endereco e telefone.",
        "se o cnpj nao retornar dados e porque foi encerrado ou nunca existiu.",
        "funciona com ou sem pontuacao.",
    ],
    # IP
    ('ip','geolocalizacao','geoloc','rastrear ip','ip falso','vpn','consulta ip','localizar ip','onde fica o ip'): [
        "ip externo vai te dar cidade, provedor, fuso e coordenadas.",
        "ip de vpn mostra o servidor da vpn, nao o ip real.",
        "digita o ip no formato 189.6.100.1",
        "nao rastreia dono, so localizacao e provedor.",
        "se o cara usa vpn vai mostrar o ip da vpn. limitacao da consulta.",
    ],
    # PLACA
    ('placa','veiculo','carro','moto','detran','mercosul','consulta placa'): [
        "placa antiga: ABC1234. mercosul: ABC1D23. sem espacos.",
        "tenta puxar marca, modelo, ano, cor e municipio.",
        "se a api de placa tiver fora do ar aparece indisponivel.",
        "detran nao tem api publica entao depende de servico terceiro.",
    ],
    # DDD
    ('ddd','codigo de area','area','consulta ddd'): [
        "manda so 2 digitos. ex: 11 pra sao paulo, 21 pro rio.",
        "ddd te mostra o estado e cidades que usam esse codigo.",
        "ddd 0800 nao funciona aqui. so ddd geografico.",
    ],
    # NUMERO
    ('numero','telefone','celular','operadora','vivo','claro','tim','oi','chip','portabilidade','consulta numero'): [
        "manda o numero com ddd. ex: 11987654321",
        "mostra operadora, tipo (celular ou fixo), regiao e estado.",
        "nome do dono nao aparece. isso e dado privado que so base paga tem.",
        "numero de outro pais coloca o + antes. ex: +14155552671",
        "operadora pode aparecer como a original mesmo com portabilidade.",
    ],
    # NUMERO TEMP
    ('numero temp','numerotemp','sms','sms temporario','numero temporario','receber sms','verificacao','codigo de verificacao','otp','2fa','sms24','nova janela','monitor sms'): [
        "opcao 02 do menu. busca numeros em sms24.me automaticamente.",
        "escolhe o pais, depois o numero, e abre o monitor em nova janela.",
        "a janela atualiza a cada 5 segundos sozinha.",
        "quando fechar a janela, o arquivo temporario e deletado automatico.",
        "util pra cadastros, verificacao de conta, 2fa sem expor seu numero.",
        "se nenhum numero aparecer, pode ser que o site esteja fora. tenta de novo.",
        "digita M pra colocar qualquer numero manualmente.",
        "o monitor so funciona se o beautifulsoup4 tiver instalado.",
    ],
    # USERNAME OSINT
    ('username','usuario','nick','apelido','osint','perfil','redes sociais','plataformas','consulta username','buscar usuario'): [
        "digita o username e ele varre 20 plataformas ao mesmo tempo.",
        "mostra onde o usuario existe: github, instagram, tiktok, steam e mais.",
        "usa threading pra checar tudo em paralelo, rapido.",
        "so verifica se o perfil existe. nao acessa o conteudo.",
        "sensivel a maiusculas dependendo da plataforma.",
    ],
    # EMAIL OSINT
    ('email','email osint','vazamento','breach','leak','email comprometido','emailrep','consulta email'): [
        "analisa reputacao do email, vazamentos e perfis associados.",
        "usa emailrep.io pra checar se o email aparece em bases vazadas.",
        "tambem verifica se e email descartavel.",
        "resultado suspeito nao significa crime, so que o email aparece em bases.",
        "email corporativo geralmente tem mais referencias do que pessoal.",
    ],
    # DOMINIO WHOIS
    ('dominio','whois','site','dns','registro','registrobr','titular','consulta dominio','quem registrou'): [
        "digita o dominio ex: google.com.br",
        "mostra titular, data de criacao, expiracao e nameservers.",
        "se o dominio estiver disponivel, aparece LIVRE.",
        "so funciona pra dominios .br via registro.br.",
        "nameservers revelam o provedor de hospedagem.",
    ],
    # BIN CARTAO
    ('bin','cartao','credito','debito','visa','mastercard','bandeira','banco emissor','consulta bin'): [
        "bin sao os primeiros 6 digitos do cartao.",
        "mostra bandeira, tipo (credito/debito), banco emissor e pais.",
        "nao acessa saldo, nao valida cartao. so identifica o banco.",
        "usa binlist.net que e publico e gratuito.",
    ],
    # SCAN DE PORTAS
    ('scan','porta','portas','port scan','portscan','servico','ssh','rdp','mysql','ftp','vulnerabilidade','aberta'): [
        "modo rapido varre as portas mais conhecidas: 21,22,80,443,3306,3389 e mais.",
        "modo range deixa voce definir inicio e fim, ex: 1 a 1024.",
        "usa threading pra ser rapido. 50 conexoes em paralelo no modo rapido.",
        "porta aberta nao significa vulnerabilidade, so que o servico ta respondendo.",
        "rdp aberto (3389) e sinal de que aceita conexao remota.",
        "mysql aberto (3306) exposto pra internet e geralmente descuido do admin.",
    ],
    # TRACEROUTE
    ('traceroute','tracert','rota','hops','saltos','caminho','rede','latencia'): [
        "mostra cada salto entre voce e o destino, com geolocalizacao de cada ip.",
        "* * * significa que o roteador nao responde ao traceroute. normal.",
        "no windows usa tracert automaticamente. no linux usa traceroute.",
        "util pra ver por onde o trafego passa e identificar bloqueios.",
        "se travar em algum hop e normal, alguns roteadores bloqueiam o probe.",
    ],
    # GERAR RELATORIO
    ('relatorio','report','txt','gerar','salvar','exportar','dox','dossie'): [
        "voce informa ip, numero, cep, username e email do alvo.",
        "ele puxa tudo de uma vez e salva num .txt na pasta.",
        "arquivo fica salvo na pasta mentanuker com data e hora no nome.",
        "quanto mais dados voce tiver do alvo, mais completo o relatorio.",
        "username puxa 8 plataformas no relatorio. email puxa reputacao e vazamento.",
    ],
    # BANCO INFO
    ('banco','ispb','codigo bancario','bancos','lista bancos','nome do banco'): [
        "opcao 1: busca por codigo. ex: 001 = banco do brasil, 341 = itau.",
        "opcao 2: lista todos os bancos com filtro por nome.",
        "usa brasilapi. cobre todos os bancos registrados no banco central.",
        "ispb e o identificador unico do banco no sistema de pagamentos.",
    ],
    # ADMIN CHECKER
    ('admin','root','administrador','privilegio','permissao','sudo'): [
        "checa se o nuker ta rodando com privilegios de administrador.",
        "windows: clica com botao direito no cmd e vai em executar como admin.",
        "linux: roda com sudo python mentanuker.py",
        "algumas funcoes como traceroute precisam de privilegio em certos sistemas.",
    ],
    # INSTALACAO / ERRO
    ('instalar','instalacao','pip','dependencia','requirements','beautifulsoup','bs4','phonenumbers','requests'): [
        "roda: python -m pip install requests phonenumbers beautifulsoup4",
        "se pip nao for reconhecido usa: python -m pip install ...",
        "python 3.8 pra cima funciona melhor.",
        "beautifulsoup4 e necessario pro numero temp funcionar.",
    ],
    # ERRO GERAL
    ('erro','bug','nao funciona','travou','crashou','problema','falha','error','exception','import error'): [
        "a maioria dos erros e conexao. verifica se ta com internet.",
        "se aparecer ModuleNotFoundError: python -m pip install requests phonenumbers beautifulsoup4",
        "se travar no import verifica se ta dentro da pasta mentanuker.",
        "erro de api geralmente e a api fora do ar, nao e o nuker.",
        "reinstala: python -m pip install --upgrade requests phonenumbers beautifulsoup4",
    ],
    # API / DADOS
    ('api','fonte','de onde','dados','banco de dados','de onde vem','como funciona'): [
        "nao vou te contar de onde vem. so usa.",
        "fontes abertas e livres. nada ilegal.",
        "informacao publica, acesso publico. simples assim.",
        "cada modulo usa uma fonte diferente. tudo sem chave de api.",
    ],
    # PRIVACIDADE / LGPD
    ('lgpd','lei','privacidade','ilegal','crime','proibido','posso usar','e ilegal'): [
        "tudo aqui e dado publico. cep, cnpj, ip, ddd. nada e privado.",
        "a ferramenta nao armazena nada. consulta, mostra e apaga.",
        "uso adequado e responsabilidade de quem usa.",
        "cnpj e cep sao publicos por lei. ip e publico por natureza.",
    ],
    # ATUALIZACAO
    ('atualizar','update','versao','nova versao','upgrade','git pull'): [
        "usa a opcao 18 do menu.",
        "precisa ter git instalado pra atualizar pelo menu.",
        "se preferir baixa o zip novo e substitui os arquivos.",
    ],
    # SAUDACAO
    ('oi','ola','oie','e ai','salve','bom dia','boa tarde','boa noite','hey','opa'): [
        "fala. o que voce quer saber?",
        "oi. qual e a duvida?",
        "salve. pergunta ai.",
        "to aqui. manda.",
        "opa. pode falar.",
    ],
    # OPCOES DO MENU
    ('menu','opcoes','o que tem','funcoes','lista','o que faz','comandos'): [
        "01-username  02-numerotemp  03-ip  04-email  05-numero",
        "06-dominio  07-cep  08-cnpj  09-placa  10-bin  11-ddd",
        "12-portscan  13-traceroute  14-relatorio  15-banco  16-admin",
        "17-ajuda  18-atualizar  19-sair",
    ],
    # FALLBACK
    (): [
        "nao entendi. tenta reformular.",
        "nao captei. pergunta de outro jeito.",
        "nao tenho resposta pra isso. tenta sobre as funcoes do nuker.",
        "essa nao ta no meu banco ainda.",
        "sem resposta pra isso. tenta outra.",
    ],
}

def buscar(texto):
    texto = texto.lower().strip()
    for chaves, respostas in BASE.items():
        if not chaves: continue
        for c in chaves:
            if c in texto:
                return random.choice(respostas)
    return random.choice(BASE[()])

def consultar():
    clear()
    print(f'\n{Ired}{"=" * 52}')
    print(f'{Gpurple}           AJUDA  -  ASA DELTA')
    print(f'{Ired}{"=" * 52}{VRCRM}')
    print(f'{Nyellow}  pergunta sobre qualquer funcao do asa delta.')
    print(f'{Nyellow}  digita {Ired}sair{Nyellow} pra voltar.{VRCRM}\n')
    while True:
        pergunta = input(f'{Hcyan}>>> {VRCRM}').strip()
        if not pergunta: continue
        if pergunta.lower() in ('sair','exit','voltar','q','0'):
            clear(); break
        print(f'\n{Dgreen}  {buscar(pergunta)}{VRCRM}\n')
