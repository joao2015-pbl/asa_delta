# -*- coding: utf-8 -*-
# Painel Asa Delta v1.0

Ired='\033[1;31m'; Dgreen='\033[1;32m'; Nyellow='\033[1;33m'
Hcyan='\033[1;36m'; Twhite='\033[1;37m'; VRCRM='\033[0;0m'
import os, sys, time, subprocess

def clear(): os.system('cls' if os.name == 'nt' else 'clear')
def restart():
    python = sys.executable
    os.execl(python, python, *sys.argv)

try:
    import requests
except:
    install = input(f'{Dgreen}[i]{VRCRM} Instalar dependencias?\n1-Sim  2-Nao\n>>> ').strip()
    if install in ('1','s','S'):
        os.system('python -m pip install requests phonenumbers beautifulsoup4')
        clear()
    else: exit()
    restart()

try:
    from database import (username, numerotemp, ip, email, numero, dominio,
                          cep, cnpj, placa, bin, ddd,
                          portscan, traceroute, relatorio,
                          banco, root, ajuda, banner)
except Exception as e:
    print(f'{Ired}[!] Erro ao importar: {e}{VRCRM}')
    print('Rode dentro da pasta Projeto Asa Delta/')
    exit()

def error_dialog(text):
    clear()
    print(f'\n{Ired}{"=" * 48}\n  ERRO: {text}\n{"=" * 48}{VRCRM}')
    time.sleep(2)

try:
    if __name__ == '__main__':
        up = subprocess.check_output('git pull', shell=True, stderr=subprocess.DEVNULL)
        if b'Already up to date' not in up:
            print(f'{Dgreen}[i] Atualizado. Reiniciando...{VRCRM}')
            time.sleep(2); restart()
except: pass

while True:
    try:
        banner.menu()
        opc = int(input(f'{Dgreen}>>> {VRCRM}'))
    except (ValueError, KeyboardInterrupt):
        error_dialog('Opcao invalida'); continue
    clear()
    if   opc == 1:  username.consultar()
    elif opc == 2:  numerotemp.consultar()
    elif opc == 3:  ip.consultar()
    elif opc == 4:  email.consultar()
    elif opc == 5:  numero.consultar()
    elif opc == 6:  dominio.consultar()
    elif opc == 7:  cep.consultar()
    elif opc == 8:  cnpj.consultar()
    elif opc == 9:  placa.consultar()
    elif opc == 10: bin.consultar()
    elif opc == 11: ddd.consultar()
    elif opc == 12: portscan.consultar()
    elif opc == 13: traceroute.consultar()
    elif opc == 14: relatorio.consultar()
    elif opc == 15: banco.consultar()
    elif opc == 16: root.consultar()
    elif opc == 17: ajuda.consultar()
    elif opc == 18: os.system('git pull'); restart()
    elif opc == 19: print(f'\n{Dgreen}Ate mais!{VRCRM}'); break
    else: error_dialog('Opcao incorreta')
